package com.example.viddownloader

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.format.Formatter
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class DownloadsActivity : AppCompatActivity() {

    private val items = ArrayList<DlTask>()
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private val adapter = Adapter()
    private val listener: () -> Unit = { reload() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadEngine.init(this)
        setContentView(R.layout.activity_downloads)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val t = items[pos]
            if (t.state == State.COMPLETED) {
                openItem(t)
            } else if (t.state == State.FAILED) {
                Toast.makeText(this, t.error ?: getString(R.string.failed), Toast.LENGTH_LONG).show()
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            showMenu(items[pos])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        DownloadEngine.addListener(listener)
        reload()
    }

    override fun onPause() {
        DownloadEngine.removeListener(listener)
        super.onPause()
    }

    private fun reload() {
        items.clear()
        items.addAll(DownloadEngine.snapshot().sortedByDescending { it.id })
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openItem(t: DlTask) {
        val s = t.savedUri ?: return
        val u = Uri.parse(s)
        try {
            val uri = if (u.scheme == "file") {
                FileProvider.getUriForFile(this, packageName + ".fileprovider", File(u.path ?: return))
            } else {
                u
            }
            val ext = t.name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, mime)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
        } catch (e: IllegalArgumentException) {
            Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(t: DlTask) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (t.state == State.COMPLETED) {
            labels.add(getString(R.string.extract_audio))
            actions.add { extractAudio(t) }
        }
        labels.add(getString(R.string.delete))
        actions.add { confirmDelete(t) }
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .show()
    }

    private fun extractAudio(t: DlTask) {
        Toast.makeText(this, R.string.extracting, Toast.LENGTH_SHORT).show()
        val base = t.name.substringBeforeLast('.', t.name)
        val appCtx = applicationContext
        Thread {
            var ok = false
            try {
                val pfd = DownloadEngine.openFd(t)
                if (pfd != null) {
                    try {
                        ok = AudioExtractor.extract(appCtx, pfd.fileDescriptor, base)
                    } finally {
                        pfd.close()
                    }
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (ok) R.string.extract_done else R.string.extract_failed,
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun confirmDelete(t: DlTask) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(R.string.delete_msg)
            .setPositiveButton(R.string.delete) { _, _ -> DownloadEngine.remove(t.id) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun size(n: Long): String = Formatter.formatFileSize(this, n)

    private fun statusText(t: DlTask): String {
        return when (t.state) {
            State.COMPLETED -> getString(R.string.done) + " • " + size(t.total)
            State.DOWNLOADING ->
                if (t.stopRequested) {
                    getString(R.string.stopping)
                } else if (t.isHls && t.hlsTotal > 0) {
                    getString(R.string.segments) + " " + t.hlsDone + "/" + t.hlsTotal +
                        " • " + size(t.downloaded) + " • " + size(t.speed) + "/s"
                } else {
                    size(t.downloaded) + " / " + (if (t.total > 0) size(t.total) else "?") +
                        " • " + size(t.speed) + "/s"
                }
            State.QUEUED -> getString(R.string.pending)
            State.PAUSED -> getString(R.string.paused) + " • " + size(t.downloaded)
            State.FAILED -> getString(R.string.failed) + (if (t.error != null) " • " + t.error else "")
            State.CANCELED -> ""
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView
                ?: layoutInflater.inflate(R.layout.item_download, parent, false)
            val t = items[position]
            v.findViewById<TextView>(R.id.dlTitle).text = t.name
            v.findViewById<TextView>(R.id.dlStatus).text = statusText(t)

            val bar = v.findViewById<ProgressBar>(R.id.dlBar)
            bar.visibility = if (t.state == State.COMPLETED) View.GONE else View.VISIBLE
            val hlsKnown = t.isHls && t.hlsTotal > 0
            bar.isIndeterminate = t.state == State.DOWNLOADING && t.total <= 0 && !hlsKnown
            bar.progress = if (hlsKnown) {
                t.hlsDone * 100 / t.hlsTotal
            } else if (t.total > 0) {
                (t.downloaded * 100 / t.total).toInt()
            } else {
                0
            }

            val action = v.findViewById<Button>(R.id.dlAction)
            if (t.state == State.DOWNLOADING && !t.stopRequested || t.state == State.QUEUED) {
                action.visibility = View.VISIBLE
                action.text = "⏸"
                action.setOnClickListener { DownloadEngine.pause(t.id) }
            } else if (t.state == State.PAUSED || t.state == State.FAILED) {
                action.visibility = View.VISIBLE
                action.text = if (t.state == State.FAILED) "↻" else "▶"
                action.setOnClickListener { DownloadEngine.resume(t.id) }
            } else {
                action.visibility = View.GONE
            }
            v.findViewById<Button>(R.id.dlDelete).setOnClickListener { confirmDelete(t) }
            return v
        }
    }
}
