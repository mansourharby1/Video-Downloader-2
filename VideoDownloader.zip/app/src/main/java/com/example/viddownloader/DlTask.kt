package com.example.viddownloader

import java.net.HttpURLConnection
import java.util.concurrent.CopyOnWriteArrayList

enum class State { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELED }

/** جزء من الملف بيتحمل في اتصال مستقل (من start لحد end شامل). */
class Seg(val start: Long, val end: Long, pos0: Long) {
    @Volatile var pos: Long = pos0
}

class DlTask(
    val id: Long,
    val url: String,
    name0: String,
    val ua: String?,
    val referer: String?,
    val cookie: String?
) {
    @Volatile var name: String = name0
    @Volatile var state: State = State.QUEUED
    @Volatile var downloaded: Long = 0L
    @Volatile var total: Long = -1L
    @Volatile var speed: Long = 0L
    @Volatile var error: String? = null
    @Volatile var savedUri: String? = null
    @Volatile var stopRequested: Boolean = false
    @Volatile var cancelRequested: Boolean = false

    // تحميل مقسّم لعدة اتصالات
    @Volatile var segs: List<Seg>? = null

    // بث HLS (m3u8)
    @Volatile var isHls: Boolean = false
    @Volatile var hlsTotal: Int = 0
    @Volatile var hlsDone: Int = 0
    @Volatile var hlsBytes: Long = 0L

    val conns = CopyOnWriteArrayList<HttpURLConnection>()
}
