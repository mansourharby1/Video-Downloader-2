package com.example.viddownloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.io.FileDescriptor
import java.nio.ByteBuffer

/** يستخرج مسار الصوت AAC من ملف فيديو mp4 ويحفظه m4a بدون إعادة ترميز. */
object AudioExtractor {

    fun extract(ctx: Context, src: FileDescriptor, baseName: String): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var pfd: ParcelFileDescriptor? = null
        var outUri: Uri? = null
        var outFile: File? = null
        var success = false
        try {
            extractor.setDataSource(src)

            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime == "audio/mp4a-latm") {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) return false
            extractor.selectTrack(track)

            val outName = baseName + ".m4a"
            val m: MediaMuxer = if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Audio.Media.DISPLAY_NAME, outName)
                values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/VideoDownloader")
                values.put(MediaStore.Audio.Media.IS_PENDING, 1)
                val uri = ctx.contentResolver.insert(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values
                ) ?: return false
                outUri = uri
                val p = ctx.contentResolver.openFileDescriptor(uri, "rw") ?: return false
                pfd = p
                MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                    "VideoDownloader"
                )
                dir.mkdirs()
                val f = File(dir, outName)
                outFile = f
                MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            }
            muxer = m

            val outTrack = m.addTrack(format)
            m.start()
            val buffer = ByteBuffer.allocate(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.set(0, size, extractor.sampleTime, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                m.writeSampleData(outTrack, buffer, info)
                extractor.advance()
            }
            m.stop()
            success = true
        } catch (e: Exception) {
            success = false
        } finally {
            try {
                muxer?.release()
            } catch (e: Exception) {
            }
            try {
                pfd?.close()
            } catch (e: Exception) {
            }
            try {
                extractor.release()
            } catch (e: Exception) {
            }
            val u = outUri
            if (u != null) {
                try {
                    if (success) {
                        val v = ContentValues()
                        v.put(MediaStore.Audio.Media.IS_PENDING, 0)
                        ctx.contentResolver.update(u, v, null, null)
                    } else {
                        ctx.contentResolver.delete(u, null, null)
                    }
                } catch (e: Exception) {
                }
            }
            val f = outFile
            if (f != null) {
                if (success) {
                    MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                } else {
                    f.delete()
                }
            }
        }
        return success
    }
}
