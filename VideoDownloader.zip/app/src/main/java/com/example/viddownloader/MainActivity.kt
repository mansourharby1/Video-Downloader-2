package com.example.viddownloader

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONTokener

class MainActivity : AppCompatActivity() {

    private data class Req(
        val url: String,
        val ua: String?,
        val cd: String?,
        val mime: String?,
        val title: String? = null
    )

    private lateinit var webView: WebView
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var btnDetected: Button

    private val detected = LinkedHashMap<String, String>()
    private val pending = ArrayList<Req>()
    private var warnedHost: String? = null

    private val blockedHosts = listOf(
        "youtube.com", "youtu.be", "facebook.com", "fb.watch", "instagram.com",
        "tiktok.com", "netflix.com", "primevideo.com", "disneyplus.com", "shahid.net"
    )

    private val mediaRegex = Regex(
        "\\.(mp4|m4v|webm|mkv|3gp|mov|mp3|m4a|aac|ogg|oga|wav|flac|opus|m3u8)(\\?.*)?\$",
        RegexOption.IGNORE_CASE
    )

    private val home = "https://www.google.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        DownloadEngine.init(this)

        webView = findViewById(R.id.webView)
        urlBox = findViewById(R.id.urlBox)
        progress = findViewById(R.id.progress)
        btnDetected = findViewById(R.id.btnDetected)

        setupWebView()

        findViewById<Button>(R.id.btnHome).setOnClickListener { load(home) }
        findViewById<Button>(R.id.btnGo).setOnClickListener { load(urlBox.text.toString()) }
        urlBox.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                load(urlBox.text.toString())
                true
            } else {
                false
            }
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }
        findViewById<Button>(R.id.btnForward).setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }
        findViewById<Button>(R.id.btnLink).setOnClickListener { showLinkDialog() }
        btnDetected.setOnClickListener { scanPage { showDetected() } }
        findViewById<Button>(R.id.btnDownloads).setOnClickListener {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2
            )
        }

        val shared = if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)
        } else {
            null
        }
        if (!shared.isNullOrBlank()) {
            val m = Regex("https?://\\S+").find(shared)
            load(m?.value ?: shared)
        } else {
            load(home)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val scheme = request?.url?.scheme
                return scheme != "http" && scheme != "https"
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val u = request?.url?.toString()
                if (u != null && mediaRegex.containsMatchIn(u)) {
                    runOnUiThread { addDetected(u) }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null) urlBox.setText(url)
                detected.clear()
                updateBadge()
                val host = Uri.parse(url ?: "").host
                if (host != null && isBlocked(url) && warnedHost != host) {
                    warnedHost = host
                    Toast.makeText(this@MainActivity, R.string.warn_site, Toast.LENGTH_LONG).show()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null) urlBox.setText(url)
                scanPage { }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        webView.setDownloadListener { url, ua, cd, mime, _ ->
            confirmDownload(Req(url, ua, cd, mime))
        }
    }

    private fun load(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") ->
                "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://" + t
        }
        webView.loadUrl(url)
    }

    private fun addDetected(url: String) {
        if (!detected.containsKey(url)) {
            detected[url] = URLUtil.guessFileName(url, null, null)
            updateBadge()
        }
    }

    private fun updateBadge() {
        btnDetected.text = "⬇ " + detected.size
        btnDetected.setTextColor(if (detected.isEmpty()) Color.DKGRAY else Color.RED)
    }

    private fun scanPage(done: () -> Unit) {
        val js = "(function(){var r=[];" +
            "document.querySelectorAll('video,audio,source').forEach(function(e){" +
            "var s=e.currentSrc||e.src;" +
            "if(s&&s.indexOf('http')===0){r.push(s);}});" +
            "return JSON.stringify(r);})()"
        webView.evaluateJavascript(js) { value ->
            try {
                val inner = JSONTokener(value ?: "null").nextValue() as? String
                if (inner != null) {
                    val arr = JSONArray(inner)
                    for (i in 0 until arr.length()) {
                        addDetected(arr.getString(i))
                    }
                }
            } catch (e: Exception) {
                // تجاهل أخطاء القراءة
            }
            done()
        }
    }

    private fun isBlocked(url: String?): Boolean {
        val host = Uri.parse(url ?: "").host ?: return false
        return blockedHosts.any { host == it || host.endsWith("." + it) }
    }

    private fun showDetected() {
        if (detected.isEmpty()) {
            val msg = if (isBlocked(webView.url)) R.string.unsupported_site else R.string.nothing_found
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            return
        }
        val urls = detected.keys.toList()
        val names = detected.values.toTypedArray()
        val checked = BooleanArray(urls.size) { true }
        AlertDialog.Builder(this)
            .setTitle(R.string.found_media)
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton(R.string.download_selected) { _, _ ->
                val ua = webView.settings.userAgentString
                for (i in urls.indices) {
                    if (checked[i]) startDownload(Req(urls[i], ua, null, null, webView.title))
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDownload(req: Req) {
        val name = URLUtil.guessFileName(req.url, req.cd, req.mime)
        AlertDialog.Builder(this)
            .setTitle(R.string.download)
            .setMessage(getString(R.string.confirm_download) + "\n" + name)
            .setPositiveButton(R.string.download) { _, _ -> startDownload(req) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showLinkDialog() {
        val input = EditText(this)
        input.hint = "https://example.com/video.mp4"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()
            if (clip != null && clip.startsWith("http")) input.setText(clip)
        } catch (e: Exception) {
            // تجاهل
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.paste_link_title)
            .setView(input)
            .setPositiveButton(R.string.download) { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http://") || u.startsWith("https://")) {
                    startDownload(Req(u, webView.settings.userAgentString, null, null))
                } else {
                    Toast.makeText(this, R.string.invalid_link, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun startDownload(req: Req) {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending.add(req)
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
            return
        }
        val ok = DownloadEngine.enqueue(req.url, req.ua, webView.url, req.cd, req.mime, req.title) >= 0
        Toast.makeText(
            this,
            if (ok) R.string.started else R.string.failed_start,
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            val list = ArrayList(pending)
            pending.clear()
            if (list.isNotEmpty()) {
                if (grantResults.isNotEmpty() &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED
                ) {
                    for (r in list) startDownload(r)
                } else {
                    Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private var lastClip: String? = null

    // زي IDM: لو نسخت رابط ملف فيديو/صوت، البرنامج يعرض عليك تحميله
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()
            if (txt != null && txt != lastClip && !txt.contains(" ") &&
                (txt.startsWith("http://") || txt.startsWith("https://")) &&
                mediaRegex.containsMatchIn(txt)
            ) {
                lastClip = txt
                confirmDownload(Req(txt, webView.settings.userAgentString, null, null))
            }
        } catch (e: Exception) {
            // تجاهل
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
