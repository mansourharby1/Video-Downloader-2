package com.example.viddownloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * محرك تحميل بأسلوب IDM:
 *  - تحميل مقسّم على حتى 6 اتصالات متوازية (لو السيرفر بيدعم Range)
 *  - استئناف بعد الإيقاف أو قطع النت أو إغلاق التطبيق
 *  - دعم بث HLS (m3u8) غير المشفّر
 *  - طابور (3 ملفات في نفس الوقت) وإعادة محاولة تلقائية
 */
object DownloadEngine {

    const val CH_PROGRESS = "dl_progress"
    const val CH_DONE = "dl_done"

    private const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val MAX_RETRIES = 5
    private const val MAX_CONN = 6
    private const val MIN_SEG = 2L * 1024L * 1024L

    private class HttpError(val code: Int) : IOException("HTTP " + code)
    private class NoRangeError : IOException("السيرفر مش بيدعم التحميل المقسّم")

    private enum class Outcome { DONE, STOPPED, FAILED }

    private val genericNames = setOf(
        "index", "master", "playlist", "video", "videoplayback", "stream",
        "manifest", "chunklist", "media", "download", "file", "main"
    )

    private val lock = Any()
    private val tasks = LinkedHashMap<Long, DlTask>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val changePosted = AtomicBoolean(false)
    private var app: Context? = null
    private var lastId = 0L

    @Volatile
    var serviceRunning: Boolean = false

    // ------------------------------------------------------------ init

    fun init(ctx: Context) {
        synchronized(lock) {
            if (app != null) return
            app = ctx.applicationContext
        }
        createChannels()
        load()
    }

    private fun ctx(): Context = app ?: throw IllegalStateException("DownloadEngine.init not called")

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx().getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "التحميلات الجارية", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "التحميلات المكتملة", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    // ------------------------------------------------------------ persistence

    private fun optStr(o: JSONObject, key: String): String? {
        return if (o.has(key) && !o.isNull(key)) o.getString(key) else null
    }

    private fun load() {
        val sp = ctx().getSharedPreferences("dl_engine", Context.MODE_PRIVATE)
        val raw = sp.getString("tasks", null) ?: return
        try {
            val arr = JSONArray(raw)
            synchronized(lock) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val t = DlTask(
                        o.getLong("id"),
                        o.getString("url"),
                        o.getString("name"),
                        optStr(o, "ua"),
                        optStr(o, "referer"),
                        optStr(o, "cookie")
                    )
                    t.downloaded = o.optLong("downloaded", 0L)
                    t.total = o.optLong("total", -1L)
                    t.error = optStr(o, "error")
                    t.savedUri = optStr(o, "savedUri")
                    t.isHls = o.optBoolean("isHls", false)
                    t.hlsTotal = o.optInt("hlsTotal", 0)
                    t.hlsDone = o.optInt("hlsDone", 0)
                    t.hlsBytes = o.optLong("hlsBytes", 0L)
                    val sa = o.optJSONArray("segs")
                    if (sa != null) {
                        val list = ArrayList<Seg>()
                        for (k in 0 until sa.length()) {
                            val x = sa.getJSONArray(k)
                            list.add(Seg(x.getLong(0), x.getLong(1), x.getLong(2)))
                        }
                        t.segs = list
                    }
                    val st = try {
                        State.valueOf(o.getString("state"))
                    } catch (e: Exception) {
                        State.PAUSED
                    }
                    // أي تحميل كان شغالاً قبل إغلاق التطبيق يصبح "متوقف" ويمكن استئنافه
                    t.state = if (st == State.DOWNLOADING || st == State.QUEUED) State.PAUSED else st
                    tasks[t.id] = t
                    if (t.id > lastId) lastId = t.id
                }
            }
        } catch (e: Exception) {
            // ملف حالة تالف: نتجاهله
        }
    }

    // يجب استدعاؤها والقفل ممسوك
    private fun saveLocked() {
        try {
            val arr = JSONArray()
            for (t in tasks.values) {
                val o = JSONObject()
                o.put("id", t.id)
                o.put("url", t.url)
                o.put("name", t.name)
                o.put("ua", t.ua)
                o.put("referer", t.referer)
                o.put("cookie", t.cookie)
                o.put("state", t.state.name)
                o.put("downloaded", t.downloaded)
                o.put("total", t.total)
                o.put("error", t.error)
                o.put("savedUri", t.savedUri)
                o.put("isHls", t.isHls)
                o.put("hlsTotal", t.hlsTotal)
                o.put("hlsDone", t.hlsDone)
                o.put("hlsBytes", t.hlsBytes)
                val segs = t.segs
                if (segs != null) {
                    val sa = JSONArray()
                    for (s in segs) {
                        val x = JSONArray()
                        x.put(s.start)
                        x.put(s.end)
                        x.put(s.pos)
                        sa.put(x)
                    }
                    o.put("segs", sa)
                }
                arr.put(o)
            }
            ctx().getSharedPreferences("dl_engine", Context.MODE_PRIVATE)
                .edit().putString("tasks", arr.toString()).apply()
        } catch (e: Exception) {
            // تجاهل
        }
    }

    // ------------------------------------------------------------ listeners / state

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun snapshot(): List<DlTask> = synchronized(lock) { tasks.values.toList() }

    fun activeCount(): Int = synchronized(lock) {
        tasks.values.count { it.state == State.DOWNLOADING || it.state == State.QUEUED }
    }

    fun overallProgress(): Pair<Long, Long> = synchronized(lock) {
        var d = 0L
        var tot = 0L
        for (t in tasks.values) {
            if (t.state == State.DOWNLOADING || t.state == State.QUEUED) {
                d += t.downloaded
                if (t.total > 0) tot += t.total
            }
        }
        Pair(d, tot)
    }

    private fun fireChanged() {
        if (changePosted.compareAndSet(false, true)) {
            main.postDelayed({
                changePosted.set(false)
                for (l in listeners) l()
            }, 300)
        }
    }

    private fun ensureService() {
        if (serviceRunning) return
        try {
            ContextCompat.startForegroundService(ctx(), Intent(ctx(), DownloadService::class.java))
        } catch (e: Exception) {
            // لو النظام منع تشغيل الخدمة، التحميل بيكمل طالما التطبيق شغال
        }
    }

    // ------------------------------------------------------------ public actions

    fun enqueue(
        url: String,
        ua: String?,
        referer: String?,
        cd: String?,
        mime: String?,
        title: String?
    ): Long {
        val scheme = Uri.parse(url).scheme
        if (scheme != "http" && scheme != "https") return -1L

        var name = sanitize(URLUtil.guessFileName(url, cd, mime))
        if (!title.isNullOrBlank() && genericNames.contains(baseOf(name).lowercase())) {
            name = sanitize(title.trim()).take(80) + extOf(name)
        }
        val hls = isHlsUrl(url)
        if (hls) name = baseOf(name) + ".ts"

        val cookie = try {
            CookieManager.getInstance().getCookie(url)
        } catch (e: Exception) {
            null
        }
        val t = synchronized(lock) {
            val id = maxOf(System.currentTimeMillis(), lastId + 1)
            lastId = id
            val task = DlTask(id, url, name, ua, referer, cookie)
            task.isHls = hls
            tasks[id] = task
            saveLocked()
            task
        }
        pool.execute { runTask(t) }
        fireChanged()
        return t.id
    }

    fun pause(id: Long) {
        synchronized(lock) {
            val t = tasks[id] ?: return
            if (t.state == State.QUEUED) {
                t.state = State.PAUSED
            } else if (t.state == State.DOWNLOADING) {
                t.stopRequested = true
                killConns(t)
            }
            saveLocked()
        }
        fireChanged()
    }

    fun resume(id: Long) {
        val t = synchronized(lock) {
            val x = tasks[id]
            if (x != null && (x.state == State.PAUSED || x.state == State.FAILED)) {
                x.state = State.QUEUED
                x.error = null
                saveLocked()
                x
            } else {
                null
            }
        }
        if (t != null) {
            pool.execute { runTask(t) }
            fireChanged()
        }
    }

    /** إلغاء التحميل وحذفه من القائمة (ويحذف الملف المحفوظ لو كان مكتملاً). */
    fun remove(id: Long) {
        var savedToDelete: String? = null
        var partToDelete: File? = null
        synchronized(lock) {
            val t = tasks[id]
            if (t != null) {
                if (t.state == State.DOWNLOADING) {
                    t.cancelRequested = true
                    t.stopRequested = true
                    killConns(t)
                } else {
                    t.state = State.CANCELED
                    tasks.remove(id)
                    savedToDelete = t.savedUri
                    partToDelete = partFile(t)
                    saveLocked()
                }
            }
        }
        partToDelete?.delete()
        val s = savedToDelete
        if (s != null) deleteSaved(s)
        fireChanged()
    }

    fun openFd(t: DlTask): ParcelFileDescriptor? {
        val s = t.savedUri ?: return null
        val u = Uri.parse(s)
        return try {
            if (u.scheme == "file") {
                ParcelFileDescriptor.open(File(u.path ?: return null), ParcelFileDescriptor.MODE_READ_ONLY)
            } else {
                ctx().contentResolver.openFileDescriptor(u, "r")
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ helpers

    private fun baseOf(n: String): String {
        val d = n.lastIndexOf('.')
        return if (d > 0) n.substring(0, d) else n
    }

    private fun extOf(n: String): String {
        val d = n.lastIndexOf('.')
        return if (d > 0) n.substring(d) else ""
    }

    private fun isHlsUrl(url: String): Boolean {
        val p = Uri.parse(url).path ?: return false
        return p.lowercase().endsWith(".m3u8")
    }

    private fun killConns(t: DlTask) {
        val list = ArrayList(t.conns)
        if (list.isNotEmpty()) {
            Thread {
                for (c in list) {
                    try {
                        c.disconnect()
                    } catch (e: Exception) {
                    }
                }
            }.start()
        }
    }

    private fun partFile(t: DlTask): File {
        val base = ctx().getExternalFilesDir(null) ?: ctx().filesDir
        val dir = File(base, "partial")
        dir.mkdirs()
        return File(dir, t.id.toString() + ".part")
    }

    private fun isRetryable(e: Exception): Boolean {
        return when (e) {
            is NoRangeError -> false
            is HttpError -> e.code >= 500 || e.code == 429
            else -> true
        }
    }

    private fun sleepInterruptibly(t: DlTask, ms: Int) {
        var waited = 0
        while (waited < ms && !t.stopRequested) {
            Thread.sleep(250)
            waited += 250
        }
    }

    // ------------------------------------------------------------ worker

    private fun runTask(t: DlTask) {
        synchronized(lock) {
            if (t.state != State.QUEUED) return
            t.state = State.DOWNLOADING
            t.stopRequested = false
            t.cancelRequested = false
            t.error = null
            t.speed = 0L
        }
        fireChanged()
        ensureService()

        val part = partFile(t)
        var outcome = Outcome.FAILED
        try {
            outcome = if (download(t, part)) Outcome.DONE else Outcome.STOPPED
            if (outcome == Outcome.DONE) publish(t, part)
        } catch (e: Exception) {
            if (t.stopRequested) {
                outcome = Outcome.STOPPED
            } else {
                t.error = e.message ?: e.javaClass.simpleName
                outcome = Outcome.FAILED
            }
        }

        synchronized(lock) {
            if (t.cancelRequested) {
                part.delete()
                t.state = State.CANCELED
                tasks.remove(t.id)
            } else {
                t.state = when (outcome) {
                    Outcome.DONE -> State.COMPLETED
                    Outcome.STOPPED -> State.PAUSED
                    Outcome.FAILED -> State.FAILED
                }
            }
            t.speed = 0L
            saveLocked()
        }
        fireChanged()
        if (outcome == Outcome.DONE && !t.cancelRequested) notifyDone(t)
    }

    private fun openUrl(t: DlTask, startUrl: String, range: String?): HttpURLConnection {
        val homeHost = URL(t.url).host
        var url = URL(startUrl)
        var redirects = 0
        while (true) {
            val c = url.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", t.ua ?: DEFAULT_UA)
            c.setRequestProperty("Accept-Encoding", "identity")
            if (!t.referer.isNullOrEmpty()) c.setRequestProperty("Referer", t.referer)
            if (!t.cookie.isNullOrEmpty() && url.host == homeHost) {
                c.setRequestProperty("Cookie", t.cookie)
            }
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                redirects++
                if (loc == null || redirects > 8) throw IOException("redirect error")
                url = URL(url, loc)
                continue
            }
            return c
        }
    }

    private fun fetchText(t: DlTask, url: String): String {
        val c = openUrl(t, url, null)
        t.conns.add(c)
        try {
            if (c.responseCode != 200) throw HttpError(c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            t.conns.remove(c)
            c.disconnect()
        }
    }

    /** يرجع true لو اكتمل التحميل، و false لو توقف بطلب المستخدم. */
    private fun download(t: DlTask, part: File): Boolean {
        if (t.isHls) return downloadHls(t, part)
        if (t.segs != null) return downloadSegmented(t, part)
        return downloadSingle(t, part, true)
    }

    // ------------------------------------------------------------ اتصال واحد (مع استئناف)

    private fun downloadSingle(t: DlTask, part: File, allowSegments: Boolean): Boolean {
        var attempts = 0
        while (true) {
            if (t.stopRequested) return false
            val existing = if (part.exists()) part.length() else 0L
            if (existing > 0 && t.total > 0 && existing >= t.total) {
                t.downloaded = existing
                return true
            }

            var conn: HttpURLConnection? = null
            try {
                val range: String? = if (existing > 0) {
                    "bytes=" + existing + "-"
                } else if (allowSegments) {
                    "bytes=0-"
                } else {
                    null
                }
                conn = openUrl(t, t.url, range)
                t.conns.add(conn)
                val code = conn.responseCode
                if (code == 416) {
                    part.delete()
                    t.downloaded = 0L
                    t.total = -1L
                    throw IOException("range not satisfiable")
                }
                if (code != 200 && code != 206) throw HttpError(code)

                val ct = conn.contentType ?: ""
                if (ct.startsWith("text/html", ignoreCase = true)) {
                    throw IOException("الرابط ده صفحة ويب مش ملف فيديو أو صوت")
                }
                if (ct.contains("mpegurl", ignoreCase = true)) {
                    conn.disconnect()
                    t.isHls = true
                    return downloadHls(t, part)
                }

                var startAt = existing
                if (existing > 0 && code == 200) startAt = 0L

                if (code == 206) {
                    val cr = conn.getHeaderField("Content-Range")
                    val slash = if (cr != null) cr.lastIndexOf('/') else -1
                    val parsed = if (cr != null && slash >= 0) cr.substring(slash + 1).trim().toLongOrNull() else null
                    if (parsed != null) {
                        t.total = parsed
                    } else if (conn.contentLengthLong >= 0) {
                        t.total = existing + conn.contentLengthLong
                    }
                } else {
                    t.total = conn.contentLengthLong
                }
                fixName(t, ct)

                // السيرفر بيدعم Range والملف كبير: نكمل بتحميل مقسّم على عدة اتصالات
                if (allowSegments && code == 206 && existing == 0L && t.total >= MIN_SEG) {
                    conn.disconnect()
                    t.segs = buildSegs(t.total)
                    return downloadSegmented(t, part)
                }

                val raf = RandomAccessFile(part, "rw")
                try {
                    raf.setLength(startAt)
                    raf.seek(startAt)
                    var done = startAt
                    t.downloaded = done
                    val input = conn.inputStream
                    val buf = ByteArray(64 * 1024)
                    var winStart = System.currentTimeMillis()
                    var winBytes = 0L
                    var lastSave = winStart
                    while (true) {
                        if (t.stopRequested) return false
                        val n = input.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                        done += n
                        winBytes += n
                        t.downloaded = done
                        val now = System.currentTimeMillis()
                        if (now - winStart >= 1000) {
                            t.speed = winBytes * 1000 / (now - winStart)
                            winStart = now
                            winBytes = 0L
                            fireChanged()
                        }
                        if (now - lastSave >= 3000) {
                            lastSave = now
                            synchronized(lock) { saveLocked() }
                        }
                    }
                    if (t.total > 0 && done < t.total) throw IOException("incomplete")
                    if (t.total <= 0) t.total = done
                    t.speed = 0L
                    return true
                } finally {
                    raf.close()
                }
            } catch (e: Exception) {
                if (t.stopRequested) return false
                attempts++
                if (!isRetryable(e) || attempts > MAX_RETRIES) throw e
                sleepInterruptibly(t, attempts * 2000)
            } finally {
                val c = conn
                if (c != null) {
                    t.conns.remove(c)
                    try {
                        c.disconnect()
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ تحميل مقسّم (زي IDM)

    private fun buildSegs(total: Long): List<Seg> {
        val n = minOf(MAX_CONN.toLong(), maxOf(2L, total / (1024L * 1024L))).toInt()
        val size = total / n
        val list = ArrayList<Seg>()
        for (i in 0 until n) {
            val s = i * size
            val e = if (i == n - 1) total - 1 else (i + 1) * size - 1
            list.add(Seg(s, e, s))
        }
        return list
    }

    private fun sumDone(segs: List<Seg>): Long {
        var s = 0L
        for (x in segs) s += (x.pos - x.start)
        return s
    }

    private fun downloadSegmented(t: DlTask, part: File): Boolean {
        val segs = t.segs ?: return false
        val total = t.total
        if (total <= 0) throw IOException("حجم الملف غير معروف")

        val len0 = if (part.exists()) part.length() else 0L
        val f = RandomAccessFile(part, "rw")
        try {
            if (len0 != total) {
                for (s in segs) s.pos = s.start
                f.setLength(total)
            }
        } finally {
            f.close()
        }

        val err = AtomicReference<Exception?>(null)
        val workers = ArrayList<Thread>()
        for (s in segs) {
            if (s.pos <= s.end) {
                workers.add(Thread { segWorker(t, part, s, err) })
            }
        }
        for (th in workers) th.start()

        var winStart = System.currentTimeMillis()
        var winBytes = sumDone(segs)
        var lastSave = winStart
        t.downloaded = winBytes
        while (workers.any { it.isAlive }) {
            try {
                Thread.sleep(250)
            } catch (e: InterruptedException) {
                break
            }
            val done = sumDone(segs)
            t.downloaded = done
            val now = System.currentTimeMillis()
            if (now - winStart >= 1000) {
                t.speed = (done - winBytes) * 1000 / (now - winStart)
                winStart = now
                winBytes = done
                fireChanged()
            }
            if (now - lastSave >= 3000) {
                lastSave = now
                synchronized(lock) { saveLocked() }
            }
        }
        for (th in workers) {
            try {
                th.join()
            } catch (e: InterruptedException) {
            }
        }

        if (t.stopRequested) return false
        val e = err.get()
        if (e != null) {
            if (e is NoRangeError) {
                // السيرفر مش بيدعم التقسيم فعلاً: نرجع لاتصال واحد من الأول
                t.segs = null
                part.delete()
                t.downloaded = 0L
                t.total = -1L
                return downloadSingle(t, part, false)
            }
            throw e
        }
        if (segs.any { it.pos <= it.end }) throw IOException("incomplete")
        t.downloaded = total
        t.speed = 0L
        return true
    }

    private fun segWorker(t: DlTask, part: File, seg: Seg, err: AtomicReference<Exception?>) {
        var attempts = 0
        while (!t.stopRequested && err.get() == null && seg.pos <= seg.end) {
            var conn: HttpURLConnection? = null
            try {
                conn = openUrl(t, t.url, "bytes=" + seg.pos + "-" + seg.end)
                t.conns.add(conn)
                val code = conn.responseCode
                if (code == 200) throw NoRangeError()
                if (code != 206) throw HttpError(code)

                val raf = RandomAccessFile(part, "rw")
                try {
                    raf.seek(seg.pos)
                    val input = conn.inputStream
                    val buf = ByteArray(32 * 1024)
                    while (seg.pos <= seg.end) {
                        if (t.stopRequested || err.get() != null) return
                        val want = minOf(buf.size.toLong(), seg.end - seg.pos + 1L).toInt()
                        val n = input.read(buf, 0, want)
                        if (n < 0) throw IOException("segment incomplete")
                        raf.write(buf, 0, n)
                        seg.pos = seg.pos + n
                    }
                } finally {
                    raf.close()
                }
            } catch (e: Exception) {
                if (t.stopRequested) return
                attempts++
                if (!isRetryable(e) || attempts > MAX_RETRIES) {
                    err.compareAndSet(null, e)
                    return
                }
                try {
                    sleepInterruptibly(t, attempts * 2000)
                } catch (x: InterruptedException) {
                    return
                }
            } finally {
                val c = conn
                if (c != null) {
                    t.conns.remove(c)
                    try {
                        c.disconnect()
                    } catch (x: Exception) {
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ بث HLS (m3u8) غير مشفّر

    private fun downloadHls(t: DlTask, part: File): Boolean {
        t.isHls = true
        if (!t.name.lowercase().endsWith(".ts")) t.name = baseOf(t.name) + ".ts"

        var playlistUrl = t.url
        var text = fetchText(t, playlistUrl)

        // قائمة رئيسية: نختار أعلى جودة
        if (text.contains("#EXT-X-STREAM-INF")) {
            var bestBw = -1L
            var bestUrl: String? = null
            val lines = text.lines()
            var i = 0
            while (i < lines.size) {
                val line = lines[i].trim()
                if (line.startsWith("#EXT-X-STREAM-INF")) {
                    val m = Regex("BANDWIDTH=(\\d+)").find(line)
                    val bw = m?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                    var j = i + 1
                    while (j < lines.size && (lines[j].isBlank() || lines[j].trim().startsWith("#"))) j++
                    if (j < lines.size && bw > bestBw) {
                        bestBw = bw
                        bestUrl = URL(URL(playlistUrl), lines[j].trim()).toString()
                    }
                    i = j
                }
                i++
            }
            if (bestUrl == null) throw IOException("تعذر قراءة قائمة البث")
            playlistUrl = bestUrl
            text = fetchText(t, playlistUrl)
        }

        if (!text.contains("#EXT-X-ENDLIST")) throw IOException("البث المباشر غير مدعوم")
        if (text.contains("#EXT-X-MAP")) throw IOException("نوع البث ده (fMP4) غير مدعوم")
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.startsWith("#EXT-X-KEY") && !line.contains("METHOD=NONE")) {
                throw IOException("البث ده مشفّر ومحمي ومش مدعوم")
            }
        }

        val base = URL(playlistUrl)
        val segUrls = ArrayList<String>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isNotEmpty() && !line.startsWith("#")) {
                segUrls.add(URL(base, line).toString())
            }
        }
        if (segUrls.isEmpty()) throw IOException("لا توجد مقاطع في البث")
        t.hlsTotal = segUrls.size

        val existingLen = if (part.exists()) part.length() else 0L
        if (t.hlsDone > segUrls.size || existingLen < t.hlsBytes) {
            t.hlsDone = 0
            t.hlsBytes = 0L
        }

        val raf = RandomAccessFile(part, "rw")
        try {
            raf.setLength(t.hlsBytes)
            raf.seek(t.hlsBytes)
            t.downloaded = t.hlsBytes
            var winStart = System.currentTimeMillis()
            var winBytes = 0L
            var lastSave = winStart

            for (idx in t.hlsDone until segUrls.size) {
                if (t.stopRequested) return false
                var attempt = 0
                while (true) {
                    if (t.stopRequested) return false
                    var c: HttpURLConnection? = null
                    try {
                        c = openUrl(t, segUrls[idx], null)
                        t.conns.add(c)
                        if (c.responseCode != 200) throw HttpError(c.responseCode)
                        val input = c.inputStream
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            if (t.stopRequested) return false
                            val n = input.read(buf)
                            if (n < 0) break
                            raf.write(buf, 0, n)
                            t.downloaded = t.downloaded + n
                            winBytes += n
                            val now = System.currentTimeMillis()
                            if (now - winStart >= 1000) {
                                t.speed = winBytes * 1000 / (now - winStart)
                                winStart = now
                                winBytes = 0L
                                fireChanged()
                            }
                        }
                        break
                    } catch (e: Exception) {
                        if (t.stopRequested) return false
                        attempt++
                        if (!isRetryable(e) || attempt > 3) throw e
                        raf.setLength(t.hlsBytes)
                        raf.seek(t.hlsBytes)
                        t.downloaded = t.hlsBytes
                        sleepInterruptibly(t, 1500)
                    } finally {
                        val cc = c
                        if (cc != null) {
                            t.conns.remove(cc)
                            try {
                                cc.disconnect()
                            } catch (x: Exception) {
                            }
                        }
                    }
                }
                val pointer = raf.filePointer
                synchronized(lock) {
                    t.hlsBytes = pointer
                    t.hlsDone = idx + 1
                }
                t.downloaded = pointer
                fireChanged()
                val now2 = System.currentTimeMillis()
                if (now2 - lastSave >= 3000) {
                    lastSave = now2
                    synchronized(lock) { saveLocked() }
                }
            }
            t.total = t.downloaded
            t.speed = 0L
            return true
        } finally {
            raf.close()
        }
    }

    // ------------------------------------------------------------ output

    private fun sanitize(name: String): String {
        val bad = "/\\:*?\"<>|"
        val sb = StringBuilder()
        for (ch in name) sb.append(if (bad.indexOf(ch) >= 0) '_' else ch)
        return sb.toString()
    }

    private fun fixName(t: DlTask, ct: String) {
        val dot = t.name.lastIndexOf('.')
        val ext = if (dot >= 0) t.name.substring(dot + 1).lowercase() else ""
        if (ext.isEmpty() || ext == "bin") {
            val m = ct.substringBefore(';').trim().lowercase()
            val e = MimeTypeMap.getSingleton().getExtensionFromMimeType(m)
            if (!e.isNullOrEmpty()) {
                t.name = baseOf(t.name) + "." + e
            }
        }
    }

    private fun publish(t: DlTask, part: File) {
        val c = ctx()
        val dot = t.name.lastIndexOf('.')
        val ext = if (dot >= 0) t.name.substring(dot + 1).lowercase() else ""
        val mime = if (ext == "ts") {
            "video/mp2t"
        } else {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, t.name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoDownloader")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IOException("MediaStore insert failed")
            try {
                val out = c.contentResolver.openOutputStream(uri) ?: throw IOException("open failed")
                out.use { o -> part.inputStream().use { i -> i.copyTo(o) } }
                val fin = ContentValues()
                fin.put(MediaStore.MediaColumns.IS_PENDING, 0)
                c.contentResolver.update(uri, fin, null, null)
            } catch (e: Exception) {
                try {
                    c.contentResolver.delete(uri, null, null)
                } catch (x: Exception) {
                }
                throw e
            }
            t.savedUri = uri.toString()
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "VideoDownloader"
            )
            dir.mkdirs()
            var f = File(dir, t.name)
            if (f.exists()) {
                f = File(dir, baseOf(t.name) + "_" + System.currentTimeMillis() + extOf(t.name))
            }
            part.inputStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            MediaScannerConnection.scanFile(c, arrayOf(f.absolutePath), null, null)
            t.savedUri = Uri.fromFile(f).toString()
        }
        part.delete()
    }

    private fun deleteSaved(uriStr: String) {
        try {
            val u = Uri.parse(uriStr)
            if (u.scheme == "file") {
                File(u.path ?: return).delete()
            } else {
                ctx().contentResolver.delete(u, null, null)
            }
        } catch (e: Exception) {
        }
    }

    private fun notifyDone(t: DlTask) {
        try {
            val c = ctx()
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, DownloadsActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(c, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("تم التحميل")
                .setContentText(t.name)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((t.id % 1000000L).toInt() + 100, n)
        } catch (e: Exception) {
        }
    }
}
