package com.example.viddownloader

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** خدمة أمامية بتخلي التحميل شغال حتى لو خرجت من التطبيق. */
class DownloadService : Service() {

    private val notifId = 4242
    private val listener: () -> Unit = { refresh() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DownloadEngine.init(this)
        DownloadEngine.serviceRunning = true
        DownloadEngine.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(notifId, n)
        }
        if (DownloadEngine.activeCount() == 0) stopSelfNow()
        return START_NOT_STICKY
    }

    private fun refresh() {
        if (DownloadEngine.activeCount() == 0) {
            stopSelfNow()
            return
        }
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(notifId, buildNotification())
        } catch (e: Exception) {
        }
    }

    private fun stopSelfNow() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val progress = DownloadEngine.overallProgress()
        val done = progress.first
        val total = progress.second
        val count = DownloadEngine.activeCount()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, DownloadsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, DownloadEngine.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_downloading, count))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
        if (total > 0) {
            val pct = (done * 100 / total).toInt()
            b.setProgress(100, if (pct > 100) 100 else pct, false)
        } else {
            b.setProgress(0, 0, true)
        }
        return b.build()
    }

    override fun onDestroy() {
        DownloadEngine.serviceRunning = false
        DownloadEngine.removeListener(listener)
        super.onDestroy()
    }
}
